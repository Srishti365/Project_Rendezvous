var bodyParser = require('body-parser');
const router = require('express').Router();
const models = require('../models/entry');
const nodemailer = require('nodemailer');

Host = models.host;
Visitor = models.visitor;
Entry = models.entry;

const transporter = nodemailer.createTransport({
    service:'gmail',
    auth: { 
        user: 'projectlenity365@gmail.com',
        pass: 'lenity1234'
    }
  });


function getTime(){
    var currentTime = new Date();

var currentOffset = currentTime.getTimezoneOffset();

var ISTOffset = 330;   // IST offset UTC +5:30 

var ISTTime = new Date(currentTime.getTime() + (ISTOffset + currentOffset)*60000);

// ISTTime now represents the time in IST coordinates

var hoursIST = ISTTime.getHours();
var ampm = hoursIST >= 12 ? 'pm' : 'am';
hoursIST = hoursIST % 12;
hoursIST = hoursIST ? hoursIST : 12;

// if(hoursIST>12) {
//     hoursIST = hoursIST-12;
//     x = "pm"
// }
// else x="am";
var minutesIST = ISTTime.getMinutes();
minutesIST = minutesIST < 10 ? '0'+minutesIST : minutesIST;
var time = hoursIST + ":" + minutesIST + " "+ ampm;
    return time;
}



router.get('/', (req, res, next) => {
    console.log("entered main page");
    res.json("entry form here");

});

router.post('/', async (req, res, next) => {
    try{
            console.log("posting entry");
            console.log(req.body);
            const {name, email, phone, hostname, hostemail, hostphone} = req.body;

            var newhost= new Host({
                name : hostname,
                email: hostemail,
                phone: hostphone
            });

            await newhost.save();

            var newvisitor= new Visitor({ name, email, phone });

            await newvisitor.save();
//             var today = new Date();
// var time = today.getHours() + ":" + today.getMinutes() + ":" + today.getSeconds();
// console.log("time", time);
console.log("timeee", getTime());

            var newentry = new Entry({
                host : newhost,
                visitor: newvisitor,
                checkin: getTime()
            })

            await newentry.save();

            //---------send mail to host---------------------
        const html = `Hi, host ${hostname},
        You have an appointment from a vistor:
        details are:
        name : ${name}
        email: ${email} 
        phone: ${phone}
        checkin time : ${newentry.checkin}
        Have a pleasant day!`;

        const mailOptions = {
            from: 'projectlenity365@gmail.com',
            to: hostemail,
            subject: 'Appointment Notification',
            text: html
        };

        await transporter.sendMail(mailOptions, function(error, info){
            if(error) {
            console.log(error);
            } else {
            console.log('Email sent' + info.response);
            }
            
        });


        //-----------------------------------
        console.log("newww");
        console.log(newentry);
            
        res.json({entry: newentry.id});
}
catch(error){
    next(error);
  }
});

router.post('/checkout', async (req, res, next) => {
    try{
            console.log("checking out");
            console.log(req.body);
            id = req.body.id;

            await Entry.findById(id).then(async function(entry1){
                var now1 = new Date();
                console.log(now1);
                entry1.checkout = getTime();
                entry1.save();
                console.log(entry1);

                 //---------send mail to visitor---------------------
        const html = `Hi, visitor ${entry1.visitor.name},
        phone : ${entry1.visitor.phone}
        email : ${entry1.visitor.email}
        You have checked out:
        checkin time : ${entry1.checkin}
        checkout time : ${entry1.checkout}
        host : ${entry1.host.name}
        Have a pleasant day!`;

        const mailOptions = {
            from: 'projectlenity365@gmail.com',
            to: entry1.visitor.email,
            subject: 'Appointment Notification',
            text: html
        };

        await transporter.sendMail(mailOptions, function(error, info){
            if(error) {
            console.log(error);
            } else {
            console.log('Email sent' + info.response);
            }
            
        });

        // //-----------------------------------
            });
            

           

            res.json("checked out");
}
catch(error){
    next(error);
  }
});



module.exports = router;